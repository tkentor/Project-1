# Project-1

As a user, I should see an introductory screen with instructions.

After I click "begin", I should see a quote displayed as a question.

As a user, I should see three clickable heads displayed as choices (Donald Trump, Lucille Bluth, Jack Donaghy).

As a user, I should see a new quote appear after I answer the previous question.

After I answer ten questions, I should see my score displayed.

As a user, I should see a video, gif, or link to a video displayed of one of the three individuals.